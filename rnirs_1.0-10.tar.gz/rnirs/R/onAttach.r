.onAttach <- function(libname, pkgname){
  
    packageStartupMessage(
      "Package rnirs version : 1.0-10 \n
      --- See ??rnirs for an overview of available functions \n\n
      --- A developing version of the package is available \n
      --- at https://github.com/mlesnoff/rnirs \n 
      --- You may check for more recent versions.\n" 
      )

  }
